# login-registration-system-with-authentication-nodejs-express-mysql
In this repoistory have login and registration system using nodejs, express and also used mysql for database.
express-session and validation also used in this project.


